import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC


X = np.array([[1, 1],[-1, 1], [1, -1], [-1, -1]])
print(X.shape)

Xdat = np.linspace(-10, 10, 50)
# X2 = np.linspace(-1, 1, 10)
Xdat = Xdat[(Xdat!=0)]
X2 = Xdat

Xnew = np.array([[]])
for i in range(Xdat.shape[0]):
    for j in range(X2.shape[0]):
        if i == 0 and j == 0:
            Xnew = np.array([[Xdat[i],X2[j]]])
        else:
            Xnew = np.vstack((Xnew, np.array([[Xdat[i],X2[j]]])))
        
        
        # print(np.array([Xdat[i],X2[j]]))
# print(Xnew)

y = np.array([[1],[0],[0],[1]])

clf = SVC(C = 100000, kernel = 'rbf',degree=4)
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(331)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('rbf kernel, C=100000')

clf = SVC(C = 1, kernel = 'rbf',degree=4)
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(332)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('rbf kernel, C=1')


clf = SVC(C = 0.00001, kernel = 'rbf',degree=4)
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(333)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('rbf kernel, C=0.00001')



clf = SVC(C = 100000, kernel = 'poly',degree=4)
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(334)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('poly kernel, C=100000')

clf = SVC(C = 1, kernel = 'poly',degree=4)
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(335)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('poly kernel, C=1')


clf = SVC(C = 0.00001, kernel = 'poly',degree=4)
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(336)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('poly kernel, C=0.00001')




clf = SVC(C = 100000, kernel = 'linear')
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(337)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('linear kernel, C=100000')

clf = SVC(C = 1, kernel = 'linear')
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(338)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('linear kernel, C=1')


clf = SVC(C = 0.00001, kernel = 'linear')
clf.fit(X,y)
ynew = clf.predict(Xnew)

plt.subplot(339)
plt.scatter(Xnew[:,0], Xnew[:,1], c = ynew[:], s=10)
plt.title('linear kernel, C=0.00001')

plt.tight_layout()
plt.show()